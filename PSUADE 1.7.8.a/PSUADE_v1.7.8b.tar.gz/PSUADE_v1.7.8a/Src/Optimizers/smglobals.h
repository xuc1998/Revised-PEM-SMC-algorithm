extern double *xk, *Bk, *pxk, *fxk;
extern int coarseopttype;
