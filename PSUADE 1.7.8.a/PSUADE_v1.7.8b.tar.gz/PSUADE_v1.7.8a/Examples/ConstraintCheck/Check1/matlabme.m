%  This file contains Sobol' first order indices
%  set sortFlag = 1 and set nn to be the number
%  of inputs to display.
sortFlag = 0;
nn = 2;
Mids = [
  2.5574502846003722e-01
  2.4994011767331364e-01
];
Str = {'X1','X2'};
if exist('noCLF') 
   hold off
else
   clf
end;
if (sortFlag == 1)
  [Mids, I2] = sort(Mids,'descend');
  Str  = Str(I2);
  I2 = I2(1:nn);
  Mids = Mids(1:nn);
  Str  = Str(1:nn);
end
ymin = min(Mids);
ymin = 0.0;
ymax = max(Mids);
h2 = 0.05 * (ymax - ymin);
bar(Mids,0.8);
set(gca,'linewidth',2)
set(gca,'fontweight','bold')
set(gca,'fontsize',12)
grid on
box on
axis([0  nn+1 ymin ymax])
set(gca,'XTickLabel',[]);
th=text(1:nn, repmat(ymin-0.05*(ymax-ymin),nn,1),Str,'HorizontalAlignment','left','rotation',90);
set(th, 'fontsize', 12)
set(th, 'fontweight', 'bold')
title('Sobol First Order Indices','FontWeight','bold','FontSize',12)
ylabel('Sobol Indices','FontWeight','bold','FontSize',12)
disp('Switch sortFlag to display ranked Sobol indices')
hold off
