/*  This code was computer generated */

/*

  These programs construct and manipulate orthogonal 
arrays.  They were prepared by

    Art Owen
    Department of Statistics
    Sequoia Hall
    Stanford CA 94305

  They may be freely used and shared.  This code comes
with no warranty of any kind.  Use it at your own
risk.

  I thank the Semiconductor Research Corporation and
the National Science Foundation for supporting this
work.

*/

int *xtn2t2;
int *xtn2t3;
int *xtn2t4;
int *xtn2t5;
int *xtn2t6;
int *xtn2t7;
int *xtn2t8;
int *xtn2t9;
int *xtn2t10;
int *xtn2t11;
int *xtn2t12;
int *xtn2t13;
int *xtn2t14;
int *xtn2t15;
int *xtn2t16;
int *xtn2t17;
int *xtn2t18;
int *xtn2t19;
int *xtn2t20;
int *xtn2t21;
int *xtn2t22;
int *xtn2t23;
int *xtn2t24;
int *xtn2t25;
int *xtn2t26;
int *xtn2t27;
int *xtn2t28;
int *xtn2t29;
int *xtn3t2;
int *xtn3t3;
int *xtn3t4;
int *xtn3t5;
int *xtn3t6;
int *xtn3t7;
int *xtn3t8;
int *xtn3t9;
int *xtn3t10;
int *xtn3t11;
int *xtn3t12;
int *xtn3t13;
int *xtn3t14;
int *xtn3t15;
int *xtn3t16;
int *xtn3t17;
int *xtn3t18;
int *xtn5t2;
int *xtn5t3;
int *xtn5t4;
int *xtn5t5;
int *xtn5t6;
int *xtn5t7;
int *xtn5t8;
int *xtn5t9;
int *xtn5t10;
int *xtn5t11;
int *xtn5t12;
int *xtn7t2;
int *xtn7t3;
int *xtn7t4;
int *xtn7t5;
int *xtn7t6;
int *xtn7t7;
int *xtn7t8;
int *xtn7t9;
int *xtn7t10;
int *xtn11t2;
int *xtn11t3;
int *xtn11t4;
int *xtn11t5;
int *xtn11t6;
int *xtn11t7;
int *xtn11t8;
int *xtn13t2;
int *xtn13t3;
int *xtn13t4;
int *xtn13t5;
int *xtn13t6;
int *xtn13t7;
int *xtn13t8;
int *xtn17t2;
int *xtn17t3;
int *xtn17t4;
int *xtn17t5;
int *xtn17t6;
int *xtn17t7;
int *xtn19t2;
int *xtn19t3;
int *xtn19t4;
int *xtn19t5;
int *xtn19t6;
int *xtn19t7;
int *xtn23t2;
int *xtn23t3;
int *xtn23t4;
int *xtn23t5;
int *xtn23t6;
int *xtn29t2;
int *xtn29t3;
int *xtn29t4;
int *xtn29t5;
int *xtn29t6;
int *xtn31t2;
int *xtn31t3;
int *xtn31t4;
int *xtn31t5;
int *xtn31t6;
int *xtn37t2;
int *xtn37t3;
int *xtn37t4;
int *xtn37t5;
int *xtn41t2;
int *xtn41t3;
int *xtn41t4;
int *xtn41t5;
int *xtn43t2;
int *xtn43t3;
int *xtn43t4;
int *xtn43t5;
int *xtn47t2;
int *xtn47t3;
int *xtn47t4;
int *xtn47t5;
