#define	USGS_CLASSIFICATION       
#undef	RDGRID                    
#undef	RAWdata_update            
#undef	DYN_PHENOLOGY             
#undef	SOILINI                   
#define	LANDONLY                  
#undef	LAND_SEA                  
#undef	SOIL_REFL_GUESSED         
#define	SOIL_REFL_READ            
#define	WO_MONTHLY           
#define	WR_MONTHLY           
#undef	CLMDEBUG                  
#define	USE_CRUNCEP_DATA          
#define	HEIGHT_V 100.        
#define	HEIGHT_T 50.        
#define	HEIGHT_Q 50.        
#define	OPENMP 28                 
#undef  CaMa_Flood
